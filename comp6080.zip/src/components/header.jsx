import { Link } from 'react-router-dom'
import { useEffect, useState } from 'react'
import './header.css'
function Header() {
    const [isMobile, setIsMobile] = useState(window.innerWidth <= 800)

    useEffect(() => {
        const handleResize = () => {
            setIsMobile(window.innerWidth <= 800)
        }

        window.addEventListener('resize', handleResize)
        return () => window.removeEventListener('resize', handleResize)
    }, [])

    return (
        <header className="header">
            <img src="/vite.svg" alt="logo" className="logo" />

            <nav className="nav">
                <Link to="/">{isMobile ? 'H' : 'Home'}</Link>
                <span> | </span>
                <Link to="/blanko">{isMobile ? 'B' : 'Blanko'}</Link>
                <span> | </span>
                <Link to="/slido">{isMobile ? 'S' : 'Slido'}</Link>
                <span> | </span>
                <Link to="/tetro">{isMobile ? 'T' : 'Tetro'}</Link>
            </nav>
        </header>
    )
}

export default Header