import "./footer.css"
function Footer() {
    return (
        <footer className="footer">
            <p>© 2026 COMP6080</p>
        </footer>
    )
}

export default Footer