import React, { useState, useEffect, useCallback, useRef } from 'react';
import { incrementGamesWon } from './tools';
import './index.css';

const ROWS = 12;
const COLS = 10;

// Shapes specified in README:
// 2x2 block, 2(high)x1(wide) block, 1x1 block
const SHAPES = [
    [[1, 1], [1, 1]], // 2x2
    [[1], [1]],       // 2x1 (high x wide)
    [[1]],            // 1x1
];

const EMPTY = 0;
const LOCKED = 1;
const GREEN = 2;

const randomShape = () => SHAPES[Math.floor(Math.random() * SHAPES.length)];

function Tetro() {
    const [grid, setGrid] = useState(Array.from({ length: ROWS }, () => Array(COLS).fill(EMPTY)));
    const [currentBlock, setCurrentBlock] = useState(null);
    const [active, setActive] = useState(false);
    const [gameOver, setGameOver] = useState(false);
    
    // Using a ref to track the current block's position for the interval and event handlers
    const blockPosRef = useRef(null);
    const gridRef = useRef(grid);
    const gameOverRef = useRef(false);

    useEffect(() => {
        gridRef.current = grid;
    }, [grid]);

    useEffect(() => {
        gameOverRef.current = gameOver;
    }, [gameOver]);

    const spawnBlock = useCallback(() => {
        const shape = randomShape();
        const newBlock = {
            shape,
            x: 0,
            y: 0
        };
        setCurrentBlock(newBlock);
        blockPosRef.current = newBlock;
    }, []);

    const resetGame = useCallback(() => {
        setGrid(Array.from({ length: ROWS }, () => Array(COLS).fill(EMPTY)));
        setCurrentBlock(null);
        setActive(false);
        setGameOver(false);
        blockPosRef.current = null;
        gameOverRef.current = false;
    }, []);

    const startGame = () => {
        if (!active && !gameOver) {
            setActive(true);
            spawnBlock();
        }
    };

    const canMove = (shape, x, y, currentGrid) => {
        for (let row = 0; row < shape.length; row++) {
            for (let col = 0; col < shape[row].length; col++) {
                if (shape[row][col]) {
                    const newX = x + col;
                    const newY = y + row;
                    if (newX < 0 || newX >= COLS || newY >= ROWS || (newY >= 0 && currentGrid[newY][newX] !== EMPTY)) {
                        return false;
                    }
                }
            }
        }
        return true;
    };

    const lockBlock = useCallback(() => {
        const { shape, x, y } = blockPosRef.current;
        const newGrid = gridRef.current.map(row => [...row]);
        
        let lost = false;
        for (let row = 0; row < shape.length; row++) {
            for (let col = 0; col < shape[row].length; col++) {
                if (shape[row][col]) {
                    const blockY = y + row;
                    const blockX = x + col;
                    newGrid[blockY][blockX] = LOCKED;
                    // Loss condition: block locked higher than first 8 rows (rows 0-3)
                    if (blockY < 4) {
                        lost = true;
                    }
                }
            }
        }

        // Check for full rows and turn them green
        let greenCount = 0;
        for (let row = 0; row < ROWS; row++) {
            const isFull = newGrid[row].every(cell => cell !== EMPTY);
            if (isFull) {
                newGrid[row] = Array(COLS).fill(GREEN);
            }
            if (newGrid[row].every(cell => cell === GREEN)) {
                greenCount++;
            }
        }

        setGrid(newGrid);

        if (lost) {
            setGameOver(true);
            setActive(false);
            alert("Failed");
            resetGame();
            return;
        }

        if (greenCount >= 5) {
            setGameOver(true);
            setActive(false);
            incrementGamesWon();
            alert("Congrats!");
            resetGame();
            return;
        }

        spawnBlock();
    }, [spawnBlock, resetGame]);

    const moveDown = useCallback(() => {
        if (!active || gameOverRef.current || !blockPosRef.current) return;

        const { shape, x, y } = blockPosRef.current;
        if (canMove(shape, x, y + 1, gridRef.current)) {
            const newBlock = { ...blockPosRef.current, y: y + 1 };
            setCurrentBlock(newBlock);
            blockPosRef.current = newBlock;
        } else {
            lockBlock();
        }
    }, [active, lockBlock]);

    const moveLeft = () => {
        if (!active || gameOverRef.current || !blockPosRef.current) return;
        const { shape, x, y } = blockPosRef.current;
        if (canMove(shape, x - 1, y, gridRef.current)) {
            const newBlock = { ...blockPosRef.current, x: x - 1 };
            setCurrentBlock(newBlock);
            blockPosRef.current = newBlock;
        }
    };

    const moveRight = () => {
        if (!active || gameOverRef.current || !blockPosRef.current) return;
        const { shape, x, y } = blockPosRef.current;
        if (canMove(shape, x + 1, y, gridRef.current)) {
            const newBlock = { ...blockPosRef.current, x: x + 1 };
            setCurrentBlock(newBlock);
            blockPosRef.current = newBlock;
        }
    };

    useEffect(() => {
        if (!active || gameOver) return;

        const interval = setInterval(() => {
            moveDown();
        }, 1000);

        return () => clearInterval(interval);
    }, [active, gameOver, moveDown]);

    useEffect(() => {
        const handleKeyDown = (e) => {
            if (!active || gameOver) return;
            if (e.key === 'ArrowLeft') {
                moveLeft();
            } else if (e.key === 'ArrowRight') {
                moveRight();
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [active, gameOver]);

    const renderGrid = () => {
        const displayGrid = grid.map(row => [...row]);
        if (currentBlock) {
            const { shape, x, y } = currentBlock;
            for (let row = 0; row < shape.length; row++) {
                for (let col = 0; col < shape[row].length; col++) {
                    if (shape[row][col]) {
                        const blockY = y + row;
                        const blockX = x + col;
                        if (blockY >= 0 && blockY < ROWS && blockX >= 0 && blockX < COLS) {
                            displayGrid[blockY][blockX] = LOCKED;
                        }
                    }
                }
            }
        }

        return displayGrid.map((row, y) => 
            row.map((cell, x) => (
                <div 
                    key={`${y}-${x}`} 
                    className={`tetro-cell ${cell === LOCKED ? 'tetro-cell--filled' : ''} ${cell === GREEN ? 'tetro-cell--green' : ''}`}
                ></div>
            ))
        );
    };

    return (
        <div className="tetro-page">
            <div className="tetro-grid" onClick={startGame}>
                {renderGrid()}
            </div>
            <div className="tetro-reset-container">
                <button className="tetro-reset-button" onClick={resetGame}>Reset</button>
            </div>
        </div>
    );
}

export default Tetro;
