import { useEffect, useState } from 'react';
import './index.css';

const SCORE_URL = 'https://cgi.cse.unsw.edu.au/~cs6080/raw/data/info.json';
const STORAGE_KEY = 'gamesWon';

function Dashboard() {
    const [gamesWon, setGamesWon] = useState(0);
    const [loading, setLoading] = useState(true);

    // 从接口获取初始分数，并同步到 localStorage
    const fetchInitialScore = async () => {
        try {
            const response = await fetch(SCORE_URL);
            const data = await response.json();

            setGamesWon(data.score);
            localStorage.setItem(STORAGE_KEY, String(data.score));
        } catch (error) {
            console.error('Failed to fetch initial score:', error);

            // 如果接口失败，至少保证页面还能显示
            setGamesWon(0);
            localStorage.setItem(STORAGE_KEY, '0');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        const savedScore = localStorage.getItem(STORAGE_KEY);

        if (savedScore !== null) {
            setGamesWon(Number(savedScore));
            setLoading(false);
        } else {
            fetchInitialScore();
        }
    }, []);

    const handleReset = async () => {
        setLoading(true);
        await fetchInitialScore();
    };

    return (
        <main className="dashboard">
            <div className="dashboard-content">
                <p className="dashboard-message">
                    Please choose an option from the navbar.
                </p>

                <div className="dashboard-score">
                    Games won: {loading ? 'Loading...' : gamesWon}{' '}
                    <button onClick={handleReset} className="reset-button">
                        (reset)
                    </button>
                </div>
            </div>
        </main>
    );
}

export default Dashboard;