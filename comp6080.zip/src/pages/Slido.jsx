import { useState, useEffect, useMemo, useRef } from "react";
import { incrementGamesWon } from "./tools"; // 这个是用来加分的函数
import "./index.css";

const SOLVED_BOARD = [1, 2, 3, 4, 5, 6, 7, 8, 0];
function Slido() {
    const [board, setBoard] = useState([]);
    const [hasmoves, sethasMoves] = useState(false);
    const [isSolvedState, setIsSolvedState] = useState(false);
    const boardRef = useRef(null);

    const imageMap = useMemo(() => ({
        1: "../assets/1.png",
        2: "../assets/2.png",
        3: "../assets/3.png",
        4: "../assets/4.png",
        5: "../assets/5.png",
        6: "../assets/6.png",
        7: "../assets/7.png",
        8: "../assets/8.png",
    }), []);
    const isSolved = (currentBoard) => {
        return currentBoard.every((value, index) => value === SOLVED_BOARD[index]);
    }
    const getRandomBoard = () => {
        let shuffledBoard = [...SOLVED_BOARD];
        do {
            shuffledBoard = shuffledBoard.sort(() => Math.random() - 0.5);
        } while (isSolved(shuffledBoard));
        return shuffledBoard;
    }
    const startNewGame = () => {
        const newBoard = getRandomBoard();
        setBoard(newBoard);
        sethasMoves(false);
        setIsSolvedState(false);
    }
    useEffect(() => {
        startNewGame();
    }, []);
    const canMove = (fromIndex, blankIndex) => {
        const row = Math.floor(fromIndex / 3);
        const col = fromIndex % 3;
        const blankRow = Math.floor(blankIndex / 3);
        const blankCol = blankIndex % 3;
        const rowDiff = Math.abs(row - blankRow);
        const colDiff = Math.abs(col - blankCol);
        return (rowDiff === 1 && colDiff === 0) || (rowDiff === 0 && colDiff === 1);
    }
    const moveTile = (tileIndex) => {
        if (isSolvedState) return;
        const blankIndex = board.indexOf(0);
        if (!canMove(tileIndex, blankIndex)) return;
        const newBoard = [...board];
        [newBoard[tileIndex], newBoard[blankIndex]] = [newBoard[blankIndex], newBoard[tileIndex]];
        setBoard(newBoard);
        sethasMoves(true);
        if (isSolved(newBoard)) {
            setIsSolvedState(true);
            incrementGamesWon();
            alert("You won!");
            startNewGame();
        }
    };
    const handleKeyDown = (event) => {
        if (isSolvedState) return;
        const blankIndex = board.indexOf(0);
        let tileIndex = -1;
        if (event.key === "ArrowUp") {
            moveTile(board.indexOf(0) - 3);
        } else if (event.key === "ArrowDown") {
            moveTile(board.indexOf(0) + 3);
        } else if (event.key === "ArrowLeft") {
            moveTile(board.indexOf(0) - 1);
        } else if (event.key === "ArrowRight") {
            moveTile(board.indexOf(0) + 1);
        } else {
            return;
        }
        if (tileIndex < 0 || tileIndex >= 9) return;
        if (
            (event.key === "ArrowLeft" && Math.floor(tileIndex / 3) !== Math.floor(blankIndex / 3))(event.key === "ArrowRight" && Math.floor(tileIndex / 3) !== Math.floor)
        ) {
            return;
        }
        moveTile(tileIndex);
    }
    const handleSolved = () => {
        if (isSolvedState) return;
        setBoard([...SOLVED_BOARD]);
        setIsSolvedState(true);
    };
    return (
        <div className="slido-page">
            <div className="slido-grid" ref={boardRef} tabIndex={0} onKeyDown={handleKeyDown} onClick={() => boardRef.current && boardRef.current.focus()}>
                {board.map((tile, index) =>
                    <button key={index} className="slido-cell" onClick={() => tile !== 0 && moveTile(index)} type="button">
                        {tile !== 0 ? (
                            <img src={imageMap[tile]} alt={`Tile ${tile}`} className="slido-image" onClick={() => moveTile(tile)} />
                        ) : null}
                    </button>
                )}
            </div>
            <div className="slido-buttons">
                <button className="slido-button" onClick={handleSolved} disabled={isSolvedState}>Solve</button>
                <button className="slido-button" onClick={startNewGame} disabled={!hasmoves}>New Game</button>
            </div>
        </div>
    );

}
export default Slido;