export const incrementGamesWon = () => {
    const current = Number(localStorage.getItem('gamesWon') || '0');
    localStorage.setItem('gamesWon', String(current + 1));
};
export const Blankostrs = [
    'the fat cats',
    'larger frogs',
    'banana cakes',
    'unsw vs usyd',
    'french toast',
    'hawaii pizza',
    'barack obama',
];