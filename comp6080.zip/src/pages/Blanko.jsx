import { useEffect, useState } from "react";
import { incrementGamesWon, Blankostrs } from "./tools";
import "./index.css";

function Blanko() {
    const [answer, setAnswer] = useState("");
    const [hiddenIndexs, setHiddenIndexs] = useState([]);
    const [inputs, setInputs] = useState({})
    const startNewGame = () => {
        const randomIndex = Math.floor(Math.random() * Blankostrs.length);
        const randomStr = Blankostrs[randomIndex];
        const availableIndexs = randomStr.split("").map((char, i) => char !== " " ? i : null).filter(i => i !== null);
        const shuffled = [...availableIndexs].sort(() => Math.random() - 0.5);
        const selected = shuffled.slice(0, 3); // 3 random indexs

        const initalInputs = {};
        selected.forEach(index => {
            initalInputs[index] = ""
        });
        setAnswer(randomStr);
        setInputs(initalInputs);// 12
        setHiddenIndexs(selected);
    };
    useEffect(() => {
        startNewGame();
    }, []);
    const handleInputChange = (e, index) => {
        const value = e.target.value.slice(0, 1);
        const newInputs = { ...inputs, [index]: value };
        setInputs(newInputs);
        const allFilled = hiddenIndexs.every(index => newInputs[index] && newInputs[index].length === 1);
        if (!allFilled) return;
        const correct = hiddenIndexs.every(index => newInputs[index] === answer[index]);
        if (correct) {
            incrementGamesWon();
            alert("You won!");
            startNewGame();
        }
    };
    return (
        <div className="blanko">
            <div className="blanko__game">
                {answer.split("").map((char, i) => {
                    const isHidden = hiddenIndexs.includes(i);
                    const isSpace = char === " ";
                    return (
                        <div key={i} className={`blanko__game__letter${isSpace ? " blanko__game__letter--space" : ""
                            }`}>
                            {isHidden ? (
                                <input
                                    className="blanko__game__input"
                                    type="text"
                                    maxLength="1"
                                    value={inputs[i] || ""}
                                    onChange={(e) => handleInputChange(e, i)}
                                />
                            ) : (
                                char
                            )}
                        </div>
                    );
                })}
            </div>
            <button className="blanko-reset" onClick={startNewGame}>Reset</button>
        </div>
    );
}

export default Blanko;