import './App.css'
import { Routes, Route } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Blanko  from './pages/Blanko'
import Slido  from './pages/Slido'
import Tetro from './pages/Tetro'
import Header from './components/header'
import Footer from './components/footer'
function App() {
  return (
    <div className="app">
      <Header />
      <main className='main'>
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/blanko" element={<Blanko />} />
      <Route path="/slido" element={<Slido />} />
      <Route path="/tetro" element={<Tetro />} />
    </Routes>
      </main>
      <Footer />

    </div>
  )
}

export default App
